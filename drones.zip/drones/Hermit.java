/**
 * 
 */
package drones;

/**
 * @author tbmsilva & m.lami
 *
 */
public interface Hermit extends Drone {

}
