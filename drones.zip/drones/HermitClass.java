/**
 * 
 */
package drones;

/**
 * @author tbmsilva & m.lami
 *
 */
public class HermitClass extends Atomic implements Hermit {

	/**
	 * @param droneID
	 * @param capacity
	 * @param range
	 */
	public HermitClass(String droneID, int capacity, int range) {
		super(droneID, capacity, range);
	}

}
