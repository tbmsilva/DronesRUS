/**
 * 
 */
package drones;

/**
 * @author tbmsilva & m.lami
 *
 */
public class SociableClass extends Atomic implements Sociable {

	/**
	 * @param droneID
	 * @param capacity
	 * @param range
	 */
	public SociableClass(String droneID, int capacity, int range) {
		super(droneID, capacity, range);
	}

}
