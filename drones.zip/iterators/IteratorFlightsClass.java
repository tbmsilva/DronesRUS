/**
 * 
 */
package iterators;

import flight.*;

/**
 * @author tbmsilva & m.lami
 *
 */
public class IteratorFlightsClass extends AbstractIterator implements IteratorFlights {

	public IteratorFlightsClass(Flight[] flights, int counter) {
		super(flights, counter);
	}

}
