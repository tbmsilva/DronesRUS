/**
 * 
 */
package iterators;

/**
 * @author m.lami & tbmsilva
 *
 */
public interface IteratorDrones extends Iterator {

}
