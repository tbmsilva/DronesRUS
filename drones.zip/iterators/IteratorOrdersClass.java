/**
 * 
 */
package iterators;

/**
 * @author tbmsilva
 *
 */
public class IteratorOrdersClass extends AbstractIterator implements IteratorOrders {

	public IteratorOrdersClass(Object[] objects, int counter) {
		super(objects, counter);
	}

}
