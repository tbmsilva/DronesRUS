/**
 * 
 */
package iterators;

import bases.Base;

/**
 * @author m.lami & tbmsilva
 *
 */
public class IteratorBasesClass extends AbstractIterator implements IteratorBases {

	/**
	 * 
	 */
	public IteratorBasesClass(Base[] bases, int counter) {
		// TODO Auto-generated constructor stub
		super(bases, counter);
	}
}
