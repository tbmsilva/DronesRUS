/**
 * 
 */
package iterators;

/**
 * @author m.lami & tbmsilva
 *
 */
public interface IteratorBases extends Iterator {

}
