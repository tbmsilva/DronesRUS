/**
 * 
 */
package iterators;

/**
 * @author tbmsilva & m.lami
 *
 */
public interface IteratorFlights extends Iterator {

}
