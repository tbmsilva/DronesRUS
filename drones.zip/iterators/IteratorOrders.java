/**
 * 
 */
package iterators;

/**
 * @author tbmsilva
 *
 */
public interface IteratorOrders extends Iterator {

}
