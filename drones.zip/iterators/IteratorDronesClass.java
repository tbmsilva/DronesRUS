/**
 * 
 */
package iterators;

import drones.Drone;

/**
 * @author m.lami & tbmsilva
 *
 */
public class IteratorDronesClass extends AbstractIterator implements IteratorDrones {

	public IteratorDronesClass(Drone[] drones, int counter) {
		super(drones,counter);
	}


}
